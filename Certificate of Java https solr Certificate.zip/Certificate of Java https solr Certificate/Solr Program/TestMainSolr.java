package com.indexer.Jobs;

import java.io.IOException;

import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrInputDocument;

public class TestMainSolr {

	public static void main(String[] args) throws SolrServerException, IOException {
		SolrDocument solr=new SolrDocument();
		//For Security reason SSL
		System.setProperty("javax.net.ssl.trustStore", "C:/Program Files/Java/jdk1.8.0_111/jre/lib/security/cacerts"); 
        System.setProperty("javax.net.ssl.trustStorePassword", "changeit");

		HttpSolrClient solr1=new HttpSolrClient("https://yamuna-1.globalhuntindia.com:8983/solr/Resume_shard1_replica2");
		SolrInputDocument doc1=new SolrInputDocument();
		doc1.setField("compId", "12349");
		doc1.setField("compName", "HitechPeopleInc");
		doc1.setField("empId", "hitech64");
		doc1.setField("address", "Delhi");
		System.out.println("doc1 >>"+doc1);
		  solr1.add(doc1);
		 
		
		  try{
			  if(solr1!=null)solr1.commit();
			  System.out.println("solr1 commit >> "+solr1);
		  }catch (Exception e) {
			e.printStackTrace();
		}
	}

}
