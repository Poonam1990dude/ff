package com.indexer.controller;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;

import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.common.SolrInputDocument;

import com.model.Call;

public class CallMainTest {
	 static HttpSolrClient solr= null;
	public static void main(String[] args) throws SolrServerException, IOException {
		try {
			PreparedStatement ps = null;
			ResultSet rs = null;
			String sql = null;
			System.setProperty("javax.net.ssl.trustStore", "C:/Program Files/Java/jdk1.8.0_111/jre/lib/security/cacerts"); 
	        System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
	        

			
			 solr=new HttpSolrClient("https://yamuna-1.globalhuntindia.com:8983/solr/callms_shard1_replica2");
			 	 
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
			String userName = "new_hitech";
            String password = "new_hitech";
            
            String url = "jdbc:sqlserver://192.168.1.241:1433"+";databaseName=HitechDB";
            Connection con = DriverManager.getConnection(url, userName, password);
            
           
            sql="select id,subject,action, parenttype,parentid,parentname,accountid,accountname,startdate,duration,direction,createddate,lastmodifieddate, "+
					" createdby,modifiedby,anchorid,createdusername,modifiedusername,anchorname,status,deleted,description,device,number,repeatcount, "+
					" calltype from calls  where deleted=0 "+
					" ORDER BY id ASC OFFSET 1 ROWS FETCH NEXT 10 ROWS ONLY";
            System.out.println("Query on Solr 1st time CallData ::::::" + sql);
			ps = con.prepareStatement(sql);
			ps.setQueryTimeout(60); // Used to Set TimeOut App will wait 60 sec to excute query
			rs = ps.executeQuery();
				
			    while(rs.next()) { 
				Call c = new Call();
				c.setId(rs.getString("id"));
				System.out.println("id >>> "+rs.getString("id"));
				c.setSubject(rs.getString("subject"));
				System.out.println("welcome:::::::::");
				c.setAction(rs.getString("action"));
				c.setParenttype(rs.getString("parenttype"));
				c.setParentid(rs.getString("parentid")); 				
				c.setParentname(rs.getString("parentname"));
			    c.setAccountid(rs.getString("accountid"));
				c.setAccountname(rs.getString("accountname"));
				c.setStartdate(rs.getTimestamp("startdate"));
				c.setDuration(rs.getString("duration"));
				c.setDirection(rs.getString("direction"));
				c.setCreateddate(rs.getTimestamp("createddate"));
				c.setLastmodifieddate(rs.getTimestamp("lastmodifieddate"));
				c.setCreatedby(rs.getString("createdby"));
				c.setModifiedby(rs.getString("modifiedby"));
				c.setAnchorid(rs.getString("anchorid"));
				c.setCreatedusername(rs.getString("createdusername"));
				c.setModifiedusername(rs.getString("modifiedusername"));
				c.setAnchorname(rs.getString("anchorname"));
				c.setStatus(rs.getString("status"));
				c.setDeleted(rs.getInt("deleted"));
				c.setDescription(rs.getString("description"));
				c.setDevice(rs.getString("device"));
				c.setNumber(rs.getString("number"));
				c.setRepeatcount(rs.getInt("repeatcount"));
				c.setCalltype(rs.getString("calltype"));
			    
			      
			        
			        String id=rs.getString("id");
			        String subject=rs.getString("subject");
					String action=rs.getString("action");
					String parenttype=rs.getString("parenttype");
					String parentid=rs.getString("parentid"); 				
					String parentname=rs.getString("parentname");
					String accountid=rs.getString("accountid");
					String accountname=rs.getString("accountname");
					Timestamp startdate=rs.getTimestamp("startdate");
					String duration=rs.getString("duration");
					String direction=rs.getString("direction");
					Timestamp createddate=rs.getTimestamp("createddate");
					Timestamp lastmodifieddate=rs.getTimestamp("lastmodifieddate");
					String createdby=rs.getString("createdby");
					String modifiedby=rs.getString("modifiedby");
					String anchorid=rs.getString("anchorid");
					String createdusername=rs.getString("createdusername");
					String modifiedusername=rs.getString("modifiedusername");
					String anchorname=rs.getString("anchorname");
					String status=rs.getString("status");
					int deleted=rs.getInt("deleted");
					String description=rs.getString("description");
					String device=rs.getString("device");
					String number=rs.getString("number");
					int repeatcount=rs.getInt("repeatcount");
					String calltype=rs.getString("calltype");

			    
		
		        
			  SolrInputDocument doc1 = new SolrInputDocument(); // used to fill input data
		       
		      
			    doc1.setField("id", id);
				doc1.setField("subject", subject);
				doc1.setField("action", action);
				doc1.setField("parenttype", parenttype);
				doc1.setField("parentid", parentid);
				doc1.setField("parentname", parentname);
				doc1.setField("accountid", accountid);
				doc1.setField("accountname", accountname);
				
				doc1.setField("startdate", startdate);
				doc1.setField("duration", duration);
				doc1.setField("direction", direction);
				doc1.setField("createddate", createddate);
				doc1.setField("lastmodifieddate", lastmodifieddate);
				doc1.setField("createdby", createdby);
				doc1.setField("modifiedby", modifiedby);
				doc1.setField("anchorid", anchorid);
				doc1.setField("createdusername", createdusername);
				doc1.setField("modifiedusername", modifiedusername);
				
				doc1.setField("anchorname", anchorname);
				doc1.setField("status", status);
				doc1.setField("deleted", deleted);
				doc1.setField("description", description);
				doc1.setField("device", device);
				doc1.setField("number", number);
				doc1.setField("repeatcount", repeatcount);
				doc1.setField("calltype", calltype);
				
			   solr.add(doc1);
		  //	 solr.commit();
			    System.out.println("done!!!");
		
	  }
			
		}catch (Exception e) {
			System.out.println("hello:::::::");
			if (solr != null)
				solr.commit();
			e.printStackTrace();
			// TODO: handle exception
		}
	}	

}
